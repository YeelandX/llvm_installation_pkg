#define DIM0	53
#define DIM1	67
#define DIM2	30
#define DIM3	4
#define NVAR	37
#define NDIM	4
